"""
Azure Functions (Python v2 programming model) entry point.

ONE Function App is enough for this project. It exposes the whole FastAPI app
through a single HTTP-triggered ASGI function, so every FastAPI route
(/health, /transactions, /transactions/batch, /alerts) is served by one function:

    https://<your-func-app>.azurewebsites.net/api/{route}

Deploy:
    func azure functionapp publish <your-func-app-name>
Local run:
    func start            (or: uvicorn app.main:app --reload --port 8000)
"""
import azure.functions as func
from app.main import app as fastapi_app

app = func.AsgiFunctionApp(app=fastapi_app, http_auth_level=func.AuthLevel.FUNCTION)
