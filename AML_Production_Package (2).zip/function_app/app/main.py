"""FastAPI app — AML transaction ingestion gateway.

Routes (all under /api when hosted in Azure Functions):
  GET  /health               liveness probe
  POST /transactions         ingest ONE transaction  -> Eventstream
  POST /transactions/batch   ingest up to 500        -> Eventstream
  GET  /alerts               read recent suspicious_flags from the Lakehouse SQL endpoint
"""
import logging
import os
import struct
from itertools import chain, repeat

from fastapi import FastAPI, HTTPException
from fastapi.middleware.cors import CORSMiddleware

from .schemas import Transaction, TransactionBatch, IngestResponse
from .eventhub import send_events

log = logging.getLogger("aml.api")

app = FastAPI(
    title="AML Ingestion API",
    version="2.0.0",
    description="Receives bank transactions and streams them into Microsoft Fabric "
                "(Eventstream -> Eventhouse + Lakehouse) for real-time AML detection.",
)

app.add_middleware(
    CORSMiddleware,
    allow_origins=os.environ.get("ALLOWED_ORIGINS", "http://localhost:3000").split(","),
    allow_methods=["GET", "POST"],
    allow_headers=["*"],
)


@app.get("/health")
async def health():
    return {"status": "ok", "service": "aml-ingestion-api"}


@app.post("/transactions", response_model=IngestResponse, status_code=202)
async def ingest_one(txn: Transaction):
    try:
        await send_events([txn.model_dump()])
    except Exception as exc:                      # surface infra errors as 502, not 500 stack traces
        log.exception("eventstream send failed")
        raise HTTPException(status_code=502, detail=f"Eventstream unavailable: {exc}") from exc
    return IngestResponse(status="accepted", accepted=1,
                          message=f"{txn.txn_id} sent to Fabric for AML scoring")


@app.post("/transactions/batch", response_model=IngestResponse, status_code=202)
async def ingest_batch(batch: TransactionBatch):
    try:
        sent = await send_events([t.model_dump() for t in batch.transactions])
    except Exception as exc:
        log.exception("eventstream batch send failed")
        raise HTTPException(status_code=502, detail=f"Eventstream unavailable: {exc}") from exc
    return IngestResponse(status="accepted", accepted=sent,
                          message=f"{sent} transactions sent to Fabric")


@app.get("/alerts")
async def get_alerts(limit: int = 50):
    """Read recent flags from the Lakehouse SQL analytics endpoint via Entra token auth.
    Requires app settings FABRIC_SQL_ENDPOINT + FABRIC_SQL_DATABASE and the Function App's
    managed identity granted access to the Fabric workspace (Viewer or above)."""
    server = os.environ.get("FABRIC_SQL_ENDPOINT")        # e.g. xyz.datawarehouse.fabric.microsoft.com
    database = os.environ.get("FABRIC_SQL_DATABASE", "AMLLakehouse")
    if not server:
        raise HTTPException(503, "FABRIC_SQL_ENDPOINT not configured")
    try:
        import pyodbc
        from azure.identity import DefaultAzureCredential
        token = DefaultAzureCredential().get_token("https://database.windows.net/.default").token
        tb = bytes(chain.from_iterable(zip(token.encode(), repeat(0))))
        attrs = {1256: struct.pack("<i", len(tb)) + tb}   # SQL_COPT_SS_ACCESS_TOKEN
        cn = pyodbc.connect(
            f"DRIVER={{ODBC Driver 18 for SQL Server}};SERVER={server};DATABASE={database};Encrypt=yes;",
            attrs_before=attrs,
        )
        cur = cn.cursor()
        cur.execute(
            "SELECT TOP (?) flag_id, txn_id, account_id, customer_id, pattern_type, "
            "ml_score, severity, analyst_decision, created_at "
            "FROM suspicious_flags ORDER BY created_at DESC", limit)
        cols = [c[0] for c in cur.description]
        rows = [dict(zip(cols, r)) for r in cur.fetchall()]
        cn.close()
        return {"count": len(rows), "alerts": rows}
    except HTTPException:
        raise
    except Exception as exc:
        log.exception("alert query failed")
        raise HTTPException(502, f"Fabric SQL endpoint error: {exc}") from exc
