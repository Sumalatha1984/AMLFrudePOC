"""Async Event Hub producer for the Fabric Eventstream 'Custom App' endpoint.

The connection string comes from the Eventstream source (Custom endpoint) in Fabric:
Eventstream -> AMLTransactionStream -> source 'MockUISource' -> Keys -> Connection string.
Store it in the Function App setting EVENTSTREAM_CONNECTION_STRING (Key Vault reference
in production: @Microsoft.KeyVault(SecretUri=...)).
"""
import os
import json
import logging
from datetime import datetime, timezone
from typing import List

from azure.eventhub.aio import EventHubProducerClient
from azure.eventhub import EventData

log = logging.getLogger("aml.eventhub")

_producer: EventHubProducerClient | None = None


def _conn_str() -> str:
    cs = os.environ.get("EVENTSTREAM_CONNECTION_STRING")
    if not cs:
        raise RuntimeError("EVENTSTREAM_CONNECTION_STRING app setting is not configured")
    return cs


def get_producer() -> EventHubProducerClient:
    """Reuse one producer across invocations (cold-start friendly)."""
    global _producer
    if _producer is None:
        _producer = EventHubProducerClient.from_connection_string(
            conn_str=_conn_str(),
            eventhub_name=os.environ.get("EVENTHUB_NAME", "AMLTransactionStream"),
        )
    return _producer


def enrich(payload: dict) -> dict:
    """Server-side fields the client must never control."""
    payload["timestamp"] = datetime.now(timezone.utc).strftime("%Y-%m-%d %H:%M:%S")
    payload["pattern_label"] = "PENDING"   # ground truth unknown for live traffic
    payload["ingest_source"] = "FUNCTION_APP_API"
    return payload


async def send_events(payloads: List[dict]) -> int:
    """Send a list of dict payloads as one or more Event Hub batches.
    Partition key = account_id so all events of an account land in order."""
    producer = get_producer()
    sent = 0
    i = 0
    while i < len(payloads):
        batch = await producer.create_batch(partition_key=payloads[i]["account_id"])
        while i < len(payloads):
            try:
                batch.add(EventData(json.dumps(enrich(dict(payloads[i])))))
                i += 1
                sent += 1
            except ValueError:          # batch full -> flush and start a new one
                break
        await producer.send_batch(batch)
    log.info("sent %d events to eventstream", sent)
    return sent
