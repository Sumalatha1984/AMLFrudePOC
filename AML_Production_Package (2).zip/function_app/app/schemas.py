"""Pydantic models — field names match the Lakehouse `transactions` Delta table exactly,
so Eventstream can map JSON -> columns with zero transformation."""
from pydantic import BaseModel, Field, field_validator
from typing import Optional, List
from enum import Enum


class TxnType(str, Enum):
    WIRE_OUT = "WIRE_OUT"
    WIRE_IN = "WIRE_IN"
    CASH_DEP = "CASH_DEP"
    PURCHASE = "PURCHASE"
    UPI_OUT = "UPI_OUT"
    SALARY = "SALARY"
    EMI = "EMI"


class Channel(str, Enum):
    ONLINE = "ONLINE"
    BRANCH = "BRANCH"
    ATM = "ATM"
    CARD = "CARD"
    UPI = "UPI"
    NEFT = "NEFT"
    AUTO_DEBIT = "AUTO_DEBIT"


class Transaction(BaseModel):
    txn_id: str = Field(..., min_length=3, max_length=64, examples=["TXN-900001"])
    account_id: str = Field(..., examples=["ACC-2001"])
    customer_id: str = Field(..., examples=["CUST-2001"])
    counterparty_account: Optional[str] = Field(None, examples=["ACC-EXT-7001"])
    amount: float = Field(..., gt=0, le=1_000_000_000)
    currency: str = Field("INR", min_length=3, max_length=3)
    txn_type: TxnType
    channel: Channel
    country: str = Field(..., min_length=2, max_length=2, examples=["IN"])
    merchant_cat: Optional[str] = Field(None, examples=["PERSONAL"])

    @field_validator("country", "currency")
    @classmethod
    def upper(cls, v: str) -> str:
        return v.upper()


class TransactionBatch(BaseModel):
    transactions: List[Transaction] = Field(..., min_length=1, max_length=500)


class IngestResponse(BaseModel):
    status: str
    accepted: int
    message: str
