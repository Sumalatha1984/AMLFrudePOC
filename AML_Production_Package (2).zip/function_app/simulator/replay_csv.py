"""Replay transactions.csv through the API as if it were live traffic.

Usage:
    python replay_csv.py --csv ../../data/transactions.csv --url http://localhost:8000/transactions --rps 5

For an Azure-deployed Function App:
    python replay_csv.py --csv transactions.csv \
        --url https://<func-app>.azurewebsites.net/api/transactions?code=<function-key> --rps 5
"""
import argparse, csv, json, time, urllib.request

p = argparse.ArgumentParser()
p.add_argument("--csv", required=True)
p.add_argument("--url", default="http://localhost:8000/transactions")
p.add_argument("--rps", type=float, default=5, help="requests per second")
p.add_argument("--limit", type=int, default=0, help="0 = all rows")
a = p.parse_args()

sent = 0
with open(a.csv) as f:
    for row in csv.DictReader(f):
        payload = {
            "txn_id": f"RT-{row['txn_id']}",       # new ids so replays never collide
            "account_id": row["account_id"],
            "customer_id": row["customer_id"],
            "counterparty_account": row.get("counterparty_account") or None,
            "amount": float(row["amount"]),
            "currency": row.get("currency", "INR"),
            "txn_type": row["txn_type"],
            "channel": row["channel"],
            "country": row["country"],
            "merchant_cat": row.get("merchant_cat") or None,
        }
        req = urllib.request.Request(a.url, data=json.dumps(payload).encode(),
                                     headers={"Content-Type": "application/json"})
        try:
            with urllib.request.urlopen(req, timeout=10) as r:
                sent += 1
                if sent % 50 == 0:
                    print(f"sent {sent} | last status {r.status}")
        except Exception as e:
            print("ERROR", payload["txn_id"], e)
        if a.limit and sent >= a.limit:
            break
        time.sleep(1.0 / a.rps)
print("done. total sent:", sent)
