# AML Ingestion API — Azure Function App (FastAPI + Python)

Streams bank transactions into Microsoft Fabric: **API → Eventstream → Eventhouse (KQL, 2–3 s) + Lakehouse (Delta, 30–60 s)**.

## How many functions do you need?

**One Function App with one HTTP-triggered ASGI function is enough.** The whole FastAPI
app (4 routes) is mounted behind it via `func.AsgiFunctionApp`. You do NOT need a separate
function per endpoint.

| Route | Purpose |
|---|---|
| `GET /api/health` | Liveness probe |
| `POST /api/transactions` | Ingest one transaction → Eventstream |
| `POST /api/transactions/batch` | Ingest up to 500 transactions in one call |
| `GET /api/alerts` | Read latest `suspicious_flags` from the Lakehouse SQL endpoint |

Optional extras for production (separate triggers, still in the same app):
- a **Timer trigger** for a heartbeat/synthetic test transaction every N minutes,
- an **Event Hub trigger** consumer is NOT needed — Fabric Eventstream is the consumer.

## Project layout
```
function_app/
├── function_app.py            # Azure Functions v2 entry (ASGI wrapper)
├── app/
│   ├── main.py                # FastAPI routes
│   ├── schemas.py             # Pydantic models = transactions table contract
│   └── eventhub.py            # cached async Event Hub producer
├── simulator/replay_csv.py    # replay the CSV dataset as live traffic
├── requirements.txt  host.json  local.settings.json.sample  .funcignore
```

## Local run
```bash
python -m venv .venv && source .venv/bin/activate     # Windows: .venv\Scripts\activate
pip install -r requirements.txt
cp local.settings.json.sample local.settings.json     # paste your Eventstream connection string
func start                                            # or: uvicorn app.main:app --port 8000
```

Test:
```bash
curl -X POST http://localhost:7071/api/transactions -H "Content-Type: application/json" -d '{
  "txn_id":"TXN-TEST-1","account_id":"ACC-2001","customer_id":"CUST-2001",
  "counterparty_account":"ACC-EXT-7001","amount":9400,"currency":"INR",
  "txn_type":"WIRE_OUT","channel":"ONLINE","country":"IN","merchant_cat":"PERSONAL"}'
```

## Deploy to Azure
```bash
az group create -n rg-aml-poc -l centralindia
az storage account create -n stamlpoc123 -g rg-aml-poc -l centralindia --sku Standard_LRS
az functionapp create -n func-aml-ingest -g rg-aml-poc -s stamlpoc123 \
   --consumption-plan-location centralindia --runtime python --runtime-version 3.11 --functions-version 4
az functionapp config appsettings set -n func-aml-ingest -g rg-aml-poc --settings \
   "EVENTSTREAM_CONNECTION_STRING=@Microsoft.KeyVault(SecretUri=https://<kv>.vault.azure.net/secrets/es-conn)" \
   "EVENTHUB_NAME=AMLTransactionStream"
func azure functionapp publish func-aml-ingest
```

## Production hardening checklist
- Connection string in **Key Vault**, referenced from app settings (never in code).
- Function auth level = FUNCTION (key) or front with **APIM/Entra ID** for the bank's channels.
- Partition key = `account_id` (already done) → per-account event ordering preserved.
- `pattern_label`/`timestamp` are set **server-side** so clients cannot forge labels.
- Enable Application Insights; alert on 502 rate (Eventstream down).
