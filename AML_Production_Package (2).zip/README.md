# AML Production-Ready Package v2.0
Corrects and supersedes the original "AML POC Executable Guide".

## Contents
- docs/AML_Production_Ready_Guide.docx — full corrected guide: gap analysis, data model,
  Raw-folder ingestion, KQL/Ontology rules, Function App, agents, Power BI, build order.
- data/ — 6 CSVs to upload to AMLLakehouse -> Files/raw
  (transactions 1,568 rows · accounts 157 · customers 157 · watchlists 14 ·
   historical_cases 12 · detection_rules 10)
- notebooks/ — 5 Fabric notebooks (.ipynb): 01_IngestRawToBronze, 02_DataCleaning,
  03_FeatureEngineering, 04_MLScoring, 05_RealTimeScoring. Import via
  Workspace -> Import -> Notebook, attach AMLLakehouse, run 01 first.
- function_app/ — Azure Function App (FastAPI + Python) that posts transactions to the
  Fabric Eventstream. One HTTP ASGI function = whole API. See its README for deploy steps.

## Quick start
1. Upload data/*.csv to AMLLakehouse Files/raw
2. Run notebook 01, then 02 -> 03 -> 04
3. Create Eventstream + deploy function_app + run simulator/replay_csv.py
4. Create the 9 KQL rules, agents, semantic model per the guide (Sections 7-12)
